# Physical_Computing_Project
Creative Making: Experience and Physical Computing Project

For the model’s output i wanted to make sure that it was something to do with light and so i decided to use neopixel lights and for the input it will be a button. This means that whenever the button is pressed the neopixel ring will light up and it will create a somewhat breathing effect that will look nice on the model. The light will continue for a few seconds and then it will stop and will then have to wait for the button to be pressed again.

In order to actually do the work i first needed to know if it was possible for me to make something like this, and i realised that it was similar to what we had been learning in our lessons already which was using regular LEDs to light up and implementing different inputs. Initially i wanted to make the the model light up depending on the light that was around it and to do this i tried to implement ways of using a regular sensor but i was unable to make it work the way that i had initially wanted to to work so i decided to resort to using a button instead as it was more straightforward and it will be easier for other people to understand. 

i made three models in total


For my project i referenced codes that were used in the Week 2 and Week 6.
the video presentation can be found on youtube with the link
